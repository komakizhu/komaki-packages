QX Cold Start Fix 0.1.0

Purpose
-------
For Quantumult X 1.8.1 build 951 on arm64e, this RootHide tweak changes only a
nil options argument to an empty dictionary when the Tunnel provider receives
startTunnelWithOptions:completionHandler:. Non-nil options are forwarded as-is.
Quantumult X's own persisted-error checks and provider initialization remain
active. The tweak does not launch the main app, retry, modify VPN preferences,
or change the saved profile/configuration.

Scope and logging
-----------------
The injection filter targets only
com.crossutility.quantumult-x.quantumult-x-tunnel. The tweak checks the
extension bundle ID, QX version/build, principal class, inheritance, and exact
Objective-C method signature before installing one hook. Unsupported versions
or signatures are logged and skipped. Unified log entries use [QXColdFix].

Install and rollback
--------------------
Install this deb with the device's RootHide package manager, enable its
injection/filter, then perform the required RootHide respring/restart. To roll
back, disable/remove this package and restart the extension (or respring). The
package has no maintainer scripts and does not touch the VPN profile, QX data,
configuration, or credentials.

Device validation
-----------------
Before the full matrix, verify one Settings start with QX force-quit. Confirm
the [QXColdFix] provider_start entry reports options_were_nil=YES and the
completion entry reports no error, then check that iOS reports Connected and
Safari traffic appears in QX's tunnel logs. Also verify app-origin startup
with non-nil options remains unchanged. Repeat separately with BetterCCVPN.
The attached host tests do not prove injection or VPN traffic on a device.
